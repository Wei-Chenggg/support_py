import cv2
import numpy as np

# ---------------- 基本設定 ----------------
WIN = "Voltage Divider Calculator"
W, H = 960, 560

# 顏色 (BGR)
BG    = (250, 250, 250)
BLACK = (35, 35, 35)
GRAY  = (140, 140, 140)
LGRAY = (220, 220, 220)
RED   = (60, 60, 220)
BLUE  = (210, 100, 30)
GREEN = (60, 150, 60)

FONT = cv2.FONT_HERSHEY_SIMPLEX


def put_center(img, s, cx, y, color, scale=0.55, th=1):
    """以 (cx, y) 為中心水平置中繪製文字"""
    (tw, _), _ = cv2.getTextSize(s, FONT, scale, th)
    cv2.putText(img, s, (cx - tw // 2, y), FONT, scale, color, th, cv2.LINE_AA)


def nothing(x):
    pass


# ---------------- 建立視窗與滑桿 ----------------
cv2.namedWindow(WIN, cv2.WINDOW_AUTOSIZE)
cv2.createTrackbar("Vin (mV)", WIN, 12000, 30000, nothing)
cv2.createTrackbar("R1 (ohm)", WIN, 10000, 100000, nothing)
cv2.createTrackbar("R2 (ohm)", WIN, 10000, 100000, nothing)

print("操作說明:")
print("  拖動滑桿調整 Vin / R1 / R2")
print("  s      = 存檔 snapshot.png")
print("  q / ESC = 離開")

# ---------------- 主迴圈 ----------------
while True:
    vin_mv = cv2.getTrackbarPos("Vin (mV)", WIN)
    r1     = cv2.getTrackbarPos("R1 (ohm)", WIN)
    r2     = cv2.getTrackbarPos("R2 (ohm)", WIN)

    vin = vin_mv / 1000.0

    # --- 計算 ---
    total = r1 + r2
    i_a   = (vin / total) if total > 0 else 0.0
    vout  = i_a * r2
    v1    = i_a * r1
    p1    = i_a * i_a * r1
    p2    = i_a * i_a * r2
    p_tot = p1 + p2
    ratio = (r2 / total) if total > 0 else 0.0

    img = np.full((H, W, 3), BG, np.uint8)

    # ---------- 標題 ----------
    cv2.putText(img, "Voltage Divider Calculator", (30, 44),
                FONT, 0.9, BLACK, 2, cv2.LINE_AA)
    cv2.line(img, (30, 62), (W - 30, 62), LGRAY, 1, cv2.LINE_AA)

    # ---------- 電路圖 ----------
    y0     = 210
    x_vin  = 70
    x_r1a, x_r1b = 140, 280
    x_node = 430
    x_vout = 590

    # Vin → R1
    cv2.line(img, (x_vin, y0), (x_r1a, y0), BLACK, 2, cv2.LINE_AA)
    # R1 方塊
    cv2.rectangle(img, (x_r1a, y0 - 32), (x_r1b, y0 + 32), BLACK, 2, cv2.LINE_AA)
    # R1 → 節點
    cv2.line(img, (x_r1b, y0), (x_node, y0), BLACK, 2, cv2.LINE_AA)
    # 節點 → Vout
    cv2.line(img, (x_node, y0), (x_vout, y0), BLACK, 2, cv2.LINE_AA)
    cv2.circle(img, (x_node, y0), 5, RED, -1, cv2.LINE_AA)

    # R2 (垂直)
    y_r2a, y_r2b = 290, 410
    cv2.line(img, (x_node, y0), (x_node, y_r2a), BLACK, 2, cv2.LINE_AA)
    cv2.rectangle(img, (x_node - 32, y_r2a),
                       (x_node + 32, y_r2b), BLACK, 2, cv2.LINE_AA)
    gy = y_r2b + 45
    cv2.line(img, (x_node, y_r2b), (x_node, gy), BLACK, 2, cv2.LINE_AA)

    # 接地符號
    for i, w in enumerate([64, 40, 16]):
        yy = gy + i * 10
        cv2.line(img, (x_node - w // 2, yy),
                      (x_node + w // 2, yy), BLACK, 2, cv2.LINE_AA)

    # 端子圓點
    cv2.circle(img, (x_vin,  y0), 4, BLUE, -1, cv2.LINE_AA)
    cv2.circle(img, (x_vout, y0), 4, RED,  -1, cv2.LINE_AA)

    # ---- 標註 ----
    put_center(img, "Vin", x_vin, y0 - 18, BLUE, 0.55, 2)
    put_center(img, f"{vin:.2f} V", x_vin, y0 + 46, GRAY, 0.5, 1)

    put_center(img, "R1", (x_r1a + x_r1b) // 2, y0 + 8, BLACK, 0.6, 2)
    put_center(img, f"{r1/1000:.2f} kOhm",
               (x_r1a + x_r1b) // 2, y0 - 46, GREEN, 0.5, 1)

    put_center(img, "R2", x_node, (y_r2a + y_r2b) // 2 + 8, BLACK, 0.6, 2)
    put_center(img, f"{r2/1000:.2f} kOhm",
               x_node + 90, (y_r2a + y_r2b) // 2 + 8, GREEN, 0.5, 1)

    put_center(img, "Vout", x_vout + 32, y0 - 18, RED, 0.55, 2)
    put_center(img, "GND",  x_node + 58, gy + 32, GRAY, 0.5, 1)

    # ---------- 右側數據面板 ----------
    px, py = 660, 100

    cv2.putText(img, "RESULTS", (px, py), FONT, 0.55, GRAY, 1, cv2.LINE_AA)
    cv2.line(img, (px, py + 10), (W - 30, py + 10), LGRAY, 1, cv2.LINE_AA)

    rows = [
        ("Vin",     f"{vin:8.3f} V",     BLUE),
        ("R1",      f"{r1:8d} Ohm",      BLACK),
        ("R2",      f"{r2:8d} Ohm",      BLACK),
        ("V(R1)",   f"{v1:8.3f} V",      BLACK),
        ("Vout",    f"{vout:8.3f} V",    RED),
        ("I",       f"{i_a*1e3:8.4f} mA", BLACK),
        ("P1",      f"{p1*1e3:8.4f} mW",  BLACK),
        ("P2",      f"{p2*1e3:8.4f} mW",  BLACK),
        ("P total", f"{p_tot*1e3:8.4f} mW", BLACK),
    ]

    y = py + 42
    for label, val, color in rows:
        cv2.putText(img, label, (px, y),       FONT, 0.52, GRAY,  1, cv2.LINE_AA)
        cv2.putText(img, val,   (px + 120, y), FONT, 0.52, color, 1, cv2.LINE_AA)
        y += 27

    # ---------- Vout / Vin 比例條 ----------
    bx, by = px, 440
    bw, bh = 280, 26
    cv2.putText(img, f"Vout / Vin  =  {ratio*100:.1f} %",
                (bx, by - 12), FONT, 0.55, GRAY, 1, cv2.LINE_AA)
    cv2.rectangle(img, (bx, by), (bx + bw, by + bh), BLACK, 1, cv2.LINE_AA)
    fill = int((bw - 2) * ratio)
    if fill > 0:
        cv2.rectangle(img, (bx + 1, by + 1),
                      (bx + 1 + fill, by + bh - 1), RED, -1, cv2.LINE_AA)

    # ---------- 底部提示 ----------
    cv2.putText(img, "q / ESC: quit      s: save snapshot",
                (30, H - 20), FONT, 0.48, GRAY, 1, cv2.LINE_AA)

    # ---------- 顯示 ----------
    cv2.imshow(WIN, img)

    key = cv2.waitKey(30) & 0xFF
    if key in (27, ord('q')):
        break
    elif key == ord('s'):
        cv2.imwrite("snapshot.png", img)
        print("已存檔 snapshot.png")

cv2.destroyAllWindows()