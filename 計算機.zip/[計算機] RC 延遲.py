import cv2, numpy as np, math

BG=(250,250,250); BLK=(35,35,35); GRY=(140,140,140); LGRY=(220,220,220)
RED=(60,60,220); BLU=(210,100,30); GRN=(60,150,60); ORG=(0,140,255); PUR=(180,80,180)
F = cv2.FONT_HERSHEY_SIMPLEX

def nothing(x): pass

def T(img, s, x, y, c=BLK, sc=0.5, t=1):
    cv2.putText(img, s, (x, y), F, sc, c, t, cv2.LINE_AA)

def TC(img, s, cx, y, c=BLK, sc=0.5, t=1):
    (w, _), _ = cv2.getTextSize(s, F, sc, t)
    cv2.putText(img, s, (cx - w // 2, y), F, sc, c, t, cv2.LINE_AA)

def fmt_time(t):
    if t <= 0:        return "0"
    if t < 1e-9:      return f"{t*1e12:.1f} ps"
    if t < 1e-6:      return f"{t*1e9:.2f} ns"
    if t < 1e-3:      return f"{t*1e6:.2f} us"
    if t < 1:         return f"{t*1e3:.3f} ms"
    if t < 60:        return f"{t:.4f} s"
    if t < 3600:      return f"{t/60:.3f} min"
    if t < 86400:     return f"{t/3600:.3f} hr"
    return f"{t/86400:.3f} day"


# 數量級前綴
PREFIX = [("m", 1e-3), ("", 1.0), ("k", 1e3), ("M", 1e6)]
LEVEL_LABELS = ["m", "1", "k", "M"]

WIN = "RC Delay - Discrete Levels"
cv2.namedWindow(WIN, cv2.WINDOW_AUTOSIZE)

# R：離散 level + 數值
cv2.createTrackbar("R level  (0=m 1=- 2=k 3=M)", WIN, 2, 3, nothing)
cv2.createTrackbar("R value  (1-999)",            WIN, 10, 999, nothing)
# C：離散 level + 數值
cv2.createTrackbar("C level  (0=m 1=- 2=k 3=M)", WIN, 0, 3, nothing)
cv2.createTrackbar("C value  (1-999)",            WIN, 100, 999, nothing)
# 其他
cv2.createTrackbar("Vin (V)",  WIN, 12, 24, nothing)
cv2.createTrackbar("Vth (%)",  WIN, 63, 99, nothing)

W, H = 1120, 540

print("操作說明:")
print("  R level / C level : 切換數量級 (m / - / k / M)")
print("  R value / C value : 有效數字 1~999")
print("  s      = 存檔 rc_delay_discrete.png")
print("  q / ESC = 離開")


# ---------------- 級別指示晶片 ----------------
def draw_level_chip(img, x, y, active, color):
    w, h, gap = 36, 28, 6
    for i, lv in enumerate(LEVEL_LABELS):
        cx = x + i * (w + gap)
        fill  = color if i == active else (246, 246, 246)
        txt_c = (255, 255, 255) if i == active else GRY
        border= color if i == active else LGRY
        cv2.rectangle(img, (cx, y), (cx + w, y + h), fill, -1)
        cv2.rectangle(img, (cx, y), (cx + w, y + h), border, 1)
        TC(img, lv, cx + w // 2, y + h - 9, txt_c, 0.55, 1)


# ---------------- 主迴圈 ----------------
while True:
    R_lvl = cv2.getTrackbarPos("R level  (0=m 1=- 2=k 3=M)", WIN)
    R_val = max(cv2.getTrackbarPos("R value  (1-999)", WIN), 1)
    C_lvl = cv2.getTrackbarPos("C level  (0=m 1=- 2=k 3=M)", WIN)
    C_val = max(cv2.getTrackbarPos("C value  (1-999)", WIN), 1)
    Vin   = max(cv2.getTrackbarPos("Vin (V)", WIN), 1)
    pct   = min(max(cv2.getTrackbarPos("Vth (%)", WIN), 1), 99)
    p     = pct / 100.0

    # 工程值
    R = R_val * PREFIX[R_lvl][1]
    C = C_val * PREFIX[C_lvl][1]
    R_str = f"{R_val} {PREFIX[R_lvl][0]}ohm"
    C_str = f"{C_val} {PREFIX[C_lvl][0]}F"

    tau     = R * C
    Vth     = Vin * p
    t_delay = -tau * math.log(1.0 - p)
    mono    = 1.1 * R * C
    E_vth   = 0.5 * C * Vth * Vth
    E_full  = 0.5 * C * Vin * Vin

    img = np.full((H, W, 3), BG, np.uint8)

    # ---------- 標題 ----------
    T(img, "RC Delay  -  Discrete Levels", 30, 44, BLK, 0.78, 2)
    T(img, "Vc(t) = Vin * (1 - exp(-t / tau))", 520, 44, GRY, 0.52, 1)
    cv2.line(img, (30, 62), (W - 30, 62), LGRY, 1)

    # ---------- 級別指示 ----------
    T(img, "R level:", 40, 102, GRY, 0.5, 1)
    draw_level_chip(img, 130, 82, R_lvl, BLU)

    T(img, "C level:", 40, 148, GRY, 0.5, 1)
    draw_level_chip(img, 130, 128, C_lvl, RED)

    # ---------- 左側數據 ----------
    rows = [
        ("R",              R_str,                    BLU),
        ("C",              C_str,                    RED),
        ("Vin",            f"{Vin} V",               BLK),
        ("Vth",            f"{Vth:.3f} V   ({pct}%)", PUR),
        ("tau = RC",       fmt_time(tau),            ORG),
        ("t_delay",        fmt_time(t_delay),        GRN),
        ("5 * tau",        fmt_time(5*tau),          GRY),
        ("555 mono 1.1RC", fmt_time(mono),           GRN),
        ("E @ Vth",        f"{E_vth*1e3:.4f} mJ",     ORG),
        ("E full",         f"{E_full*1e3:.4f} mJ",    ORG),
    ]
    y = 200
    for lab, val, col in rows:
        T(img, lab, 40,  y, GRY, 0.5, 1)
        T(img, val, 210, y, col, 0.5, 1)
        y += 28

    # ---------- 右側曲線 ----------
    px, py, pw, ph = 540, 110, 540, 390
    cv2.rectangle(img, (px, py), (px + pw, py + ph), (255, 255, 255), -1)
    cv2.rectangle(img, (px, py), (px + pw, py + ph), LGRY, 1)

    if tau > 0:
        tmax = 5 * tau
        def xp(t): return px + int(t / tmax * pw)
        def yp(v): return py + ph - int(v / Vin * ph)

        for k in range(6):
            gx = xp(k * tau)
            cv2.line(img, (gx, py), (gx, py + ph), LGRY, 1)
            lbl = "0" if k == 0 else f"{k}tau"
            TC(img, lbl, gx, py + ph + 18, GRY, 0.4, 1)
        for k in range(5):
            gy = yp(Vin * k / 4)
            cv2.line(img, (px, gy), (px + pw, gy), LGRY, 1)
            T(img, f"{Vin*k/4:.2f}", px - 44, gy + 4, GRY, 0.4, 1)

        yth = yp(Vth)
        cv2.line(img, (px, yth), (px + pw, yth), PUR, 1, cv2.LINE_AA)
        T(img, f"Vth = {Vth:.2f} V", px + pw - 110, yth - 6, PUR, 0.42, 1)

        pts = []
        for i in range(pw + 1):
            t = (i / pw) * tmax
            v = Vin * (1 - math.exp(-t / tau))
            pts.append((px + i, yp(v)))
        cv2.polylines(img, [np.array(pts, np.int32)], False, RED, 2, cv2.LINE_AA)

        xd = xp(t_delay)
        cv2.line(img, (xd, py), (xd, py + ph), GRN, 1, cv2.LINE_AA)
        cv2.circle(img, (xd, yth), 6, GRN, -1, cv2.LINE_AA)
        cv2.circle(img, (xd, yth), 6, (255, 255, 255), 1, cv2.LINE_AA)

        label = f"t_delay = {fmt_time(t_delay)}"
        (lw, _), _ = cv2.getTextSize(label, F, 0.46, 1)
        lx = min(xd + 8, px + pw - lw - 6)
        ly = max(yth - 12, py + 22)
        cv2.putText(img, label, (lx, ly), F, 0.46, GRN, 1, cv2.LINE_AA)
    else:
        T(img, "tau = 0", px + pw // 2 - 30, py + ph // 2, GRY, 0.7, 1)

    T(img, "q / ESC: quit      s: save", 30, H - 16, GRY, 0.45, 1)

    cv2.imshow(WIN, img)
    k = cv2.waitKey(30) & 0xFF
    if k in (27, ord('q')):
        break
    elif k == ord('s'):
        cv2.imwrite("rc_delay_discrete.png", img)
        print("已存檔 rc_delay_discrete.png")

cv2.destroyAllWindows()