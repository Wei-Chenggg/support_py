import cv2, numpy as np, math

BG=(250,250,250); BLK=(35,35,35); GRY=(140,140,140); LGRY=(220,220,220)
RED=(60,60,220); BLU=(210,100,30); GRN=(60,150,60); ORG=(0,140,255); PUR=(180,80,180)
F = cv2.FONT_HERSHEY_SIMPLEX

def nothing(x): pass
def T(img,s,x,y,c=BLK,sc=0.5,t=1): cv2.putText(img,s,(x,y),F,sc,c,t,cv2.LINE_AA)
def TC(img,s,cx,y,c=BLK,sc=0.5,t=1):
    (w,_),_=cv2.getTextSize(s,F,sc,t); cv2.putText(img,s,(cx-w//2,y),F,sc,c,t,cv2.LINE_AA)

# ---------- 格式化 ----------
def fmt_freq(f):
    if f<=0: return "0"
    if f<1e3:  return f"{f:.2f} Hz"
    if f<1e6:  return f"{f/1e3:.2f} kHz"
    if f<1e9:  return f"{f/1e6:.2f} MHz"
    return f"{f/1e9:.2f} GHz"

def fmt_ohm(z):
    if z<=0: return "0"
    if z<1:    return f"{z*1e3:.2f} mOhm"
    if z<1e3:  return f"{z:.2f} Ohm"
    if z<1e6:  return f"{z/1e3:.3f} kOhm"
    return f"{z/1e6:.3f} MOhm"

# ---------- 數量級 ----------
PREFIX      = [("m",1e-3),("",1.0),("k",1e3),("M",1e6)]
LVL_TXT     = ["m","1","k","M"]
GBW_LEVELS  = [1e6, 10e6, 100e6, 1e9]
GBW_TXT     = ["1M","10M","100M","1G"]

def draw_chip(img,x,y,active,color,labels,w=40,h=28,gap=6):
    for i,lv in enumerate(labels):
        cx = x + i*(w+gap)
        fill = color if i==active else (246,246,246)
        bd   = color if i==active else LGRY
        cv2.rectangle(img,(cx,y),(cx+w,y+h),fill,-1)
        cv2.rectangle(img,(cx,y),(cx+w,y+h),bd,1)
        TC(img,lv,cx+w//2,y+h-9,(255,255,255) if i==active else GRY,0.5,1)

# ---------- 視窗 ----------
WIN = "Op-Amp Non-Inverting"
cv2.namedWindow(WIN, cv2.WINDOW_AUTOSIZE)
cv2.createTrackbar("Rf level (m/1/k/M)", WIN, 2,   3,   nothing)
cv2.createTrackbar("Rf value (1-999)",   WIN, 100, 999, nothing)
cv2.createTrackbar("Rg level (m/1/k/M)", WIN, 2,   3,   nothing)
cv2.createTrackbar("Rg value (1-999)",   WIN, 10,  999, nothing)
cv2.createTrackbar("GBW level",          WIN, 0,   3,   nothing)
cv2.createTrackbar("Vin (0.1V)",         WIN, 100, 240, nothing)

W, H = 1200, 800
print("操作說明:")
print("  Rf/Rg: level 切換 m/1/k/M, value 為有效數字")
print("  GBW: 1M / 10M / 100M / 1G Hz")
print("  Vin: 單位 0.1V, 範圍 0.0 ~ 24.0 V")
print("  s = 存檔, q/ESC = 離開")

# ---------- 主迴圈 ----------
while True:
    Rf_lvl  = cv2.getTrackbarPos("Rf level (m/1/k/M)", WIN)
    Rf_val  = max(cv2.getTrackbarPos("Rf value (1-999)", WIN), 1)
    Rg_lvl  = cv2.getTrackbarPos("Rg level (m/1/k/M)", WIN)
    Rg_val  = max(cv2.getTrackbarPos("Rg value (1-999)", WIN), 1)
    GBW_lvl = cv2.getTrackbarPos("GBW level", WIN)
    Vin_dv  = cv2.getTrackbarPos("Vin (0.1V)", WIN)

    Rf  = Rf_val * PREFIX[Rf_lvl][1]
    Rg  = Rg_val * PREFIX[Rg_lvl][1]
    GBW = GBW_LEVELS[GBW_lvl]
    Vin = Vin_dv / 10.0

    # ---- 計算 ----
    gain    = 1.0 + Rf / Rg
    gain_db = 20 * math.log10(gain)
    Vout    = Vin * gain
    I_R     = Vin / Rg          # 流過 Rg (與 Rf 相同)
    f3db    = GBW / gain

    img = np.full((H, W, 3), BG, np.uint8)

    # ==================== 標題 ====================
    T(img, "Op-Amp Non-Inverting Amplifier", 30, 44, BLK, 0.78, 2)
    T(img, "Vout = Vin * (1 + Rf/Rg)     f-3dB = GBW / Gain", 560, 44, GRY, 0.48, 1)
    cv2.line(img, (30, 62), (W - 30, 62), LGRY, 1)

    # ==================== 左側：參數 & 結果 ====================
    T(img, "Rf:",  30, 100, GRY, 0.55, 1)
    draw_chip(img, 70, 80, Rf_lvl, BLU, LVL_TXT)
    T(img, fmt_ohm(Rf), 290, 100, BLU, 0.55, 1)

    T(img, "Rg:",  30, 152, GRY, 0.55, 1)
    draw_chip(img, 70, 132, Rg_lvl, RED, LVL_TXT)
    T(img, fmt_ohm(Rg), 290, 152, RED, 0.55, 1)

    T(img, "GBW:", 30, 204, GRY, 0.55, 1)
    draw_chip(img, 90, 184, GBW_lvl, GRN, GBW_TXT, 48)
    T(img, fmt_freq(GBW), 310, 204, GRN, 0.55, 1)

    cv2.line(img, (30, 232), (440, 232), LGRY, 1)

    T(img, "RESULTS", 30, 260, GRY, 0.5, 1)
    rows = [
        ("Vin",      f"{Vin:.2f} V",                    BLK),
        ("Vout",     f"{Vout:.4f} V",                   RED),
        ("Gain",     f"{gain:.4f}   ({gain_db:.2f} dB)", RED),
        ("I (Rf=Rg)",f"{I_R*1000:.4f} mA",              ORG),
        ("f-3dB",    fmt_freq(f3db),                    PUR),
        ("GBW",      fmt_freq(GBW),                     GRN),
    ]
    y = 292
    for lab, val, col in rows:
        T(img, lab, 40,  y, GRY, 0.5, 1)
        T(img, val, 190, y, col, 0.5, 1)
        y += 26

    T(img, "V- = V+ = Vin   (virtual short)", 40, y+8,  GRY, 0.42, 1)
    T(img, "I(Rf) = I(Rg) = Vin / Rg",        40, y+32, GRY, 0.42, 1)

    # ==================== 右上：電路圖 ====================
    cx0, cy0 = 460, 70
    cw, chh  = 710, 340
    cv2.rectangle(img, (cx0, cy0), (cx0+cw, cy0+chh), (252,252,252), -1)
    cv2.rectangle(img, (cx0, cy0), (cx0+cw, cy0+chh), LGRY, 1)
    T(img, "Circuit", cx0+12, cy0+22, GRY, 0.48, 1)

    # 運放三角形
    op_tip  = (cx0 + 370, cy0 + 170)
    op_top  = (cx0 + 280, cy0 + 120)
    op_bot  = (cx0 + 280, cy0 + 220)
    p_plus  = (cx0 + 280, cy0 + 145)
    p_minus = (cx0 + 280, cy0 + 195)

    cv2.polylines(img, [np.array([op_tip, op_top, op_bot], np.int32)],
                  True, BLK, 2, cv2.LINE_AA)
    T(img, "+", p_plus[0]+14,  p_plus[1]+7,  BLK, 0.62, 2)
    T(img, "-", p_minus[0]+14, p_minus[1]+7, BLK, 0.62, 2)

    # Vin → + 輸入
    vin_pt = (cx0 + 60, p_plus[1])
    cv2.line(img, vin_pt, p_plus, BLK, 2, cv2.LINE_AA)
    cv2.circle(img, vin_pt, 5, BLU, -1, cv2.LINE_AA)
    T(img, "Vin", vin_pt[0]-10, vin_pt[1]-14, BLU, 0.5, 1)
    T(img, f"{Vin:.2f}V", vin_pt[0]-16, vin_pt[1]+24, GRY, 0.4, 1)

    # 反相輸入節點
    node_x = cx0 + 160
    cv2.line(img, p_minus, (node_x, p_minus[1]), BLK, 2, cv2.LINE_AA)
    cv2.circle(img, (node_x, p_minus[1]), 4, RED, -1, cv2.LINE_AA)

    # Rf 迴路：節點 → 上 → 右 → 下 → 輸出
    top_y = cy0 + 55
    out_y = op_tip[1]
    fb_x  = cx0 + 540

    cv2.line(img, (node_x, p_minus[1]), (node_x, top_y), BLK, 2, cv2.LINE_AA)
    cv2.line(img, (node_x, top_y),     (fb_x, top_y),   BLK, 2, cv2.LINE_AA)
    cv2.line(img, (fb_x, top_y),       (fb_x, out_y),   BLK, 2, cv2.LINE_AA)

    rf_w, rf_h = 96, 30
    rf_cx = (node_x + fb_x) // 2
    cv2.rectangle(img, (rf_cx-rf_w//2, top_y-rf_h//2),
                       (rf_cx+rf_w//2, top_y+rf_h//2), (255,255,255), -1)
    cv2.rectangle(img, (rf_cx-rf_w//2, top_y-rf_h//2),
                       (rf_cx+rf_w//2, top_y+rf_h//2), BLK, 2, cv2.LINE_AA)
    TC(img, "Rf", rf_cx, top_y+7, BLU, 0.55, 2)
    T(img, fmt_ohm(Rf), rf_cx-42, top_y-26, BLU, 0.42, 1)

    # Rg
    rg_top = p_minus[1] + 30
    rg_bot = rg_top + 50
    cv2.line(img, (node_x, p_minus[1]), (node_x, rg_top), BLK, 2, cv2.LINE_AA)

    rg_w = 30
    cv2.rectangle(img, (node_x-rg_w//2, rg_top), (node_x+rg_w//2, rg_bot), (255,255,255), -1)
    cv2.rectangle(img, (node_x-rg_w//2, rg_top), (node_x+rg_w//2, rg_bot), BLK, 2, cv2.LINE_AA)
    TC(img, "Rg", node_x, rg_top + 30, RED, 0.55, 2)
    T(img, fmt_ohm(Rg), node_x - 108, rg_top + 27, RED, 0.42, 1)

    # 接地
    gnd_y = rg_bot + 25
    cv2.line(img, (node_x, rg_bot), (node_x, gnd_y), BLK, 2, cv2.LINE_AA)
    for i, gw in enumerate([56, 36, 16]):
        yy = gnd_y + i*10
        cv2.line(img, (node_x-gw//2, yy), (node_x+gw//2, yy), BLK, 2, cv2.LINE_AA)

    # 輸出
    vout_pt = (cx0 + 650, out_y)
    cv2.line(img, op_tip, vout_pt, BLK, 2, cv2.LINE_AA)
    cv2.circle(img, (fb_x, out_y), 4, RED, -1, cv2.LINE_AA)
    cv2.circle(img, vout_pt, 5, RED, -1, cv2.LINE_AA)
    T(img, "Vout", vout_pt[0]-36, vout_pt[1]-14, RED, 0.5, 1)
    T(img, f"{Vout:.3f}V", vout_pt[0]-42, vout_pt[1]+24, GRY, 0.4, 1)

    T(img, f"Gain = 1 + Rf/Rg = {gain:.3f}", cx0+400, cy0+chh-14, GRY, 0.42, 1)

    # ==================== 下方：頻率響應 ====================
    fx0, fy0 = 30, 430
    fw, fh   = 1140, 350
    cv2.rectangle(img, (fx0, fy0), (fx0+fw, fy0+fh), (252,252,252), -1)
    cv2.rectangle(img, (fx0, fy0), (fx0+fw, fy0+fh), LGRY, 1)
    T(img, "Frequency Response  (open-loop vs closed-loop)", fx0+12, fy0+22, GRY, 0.48, 1)

    gx0, gy0 = fx0 + 80, fy0 + 50
    gw, gh   = fw - 110, fh - 90

    f_lo, f_hi = 1.0, 1e9
    log_flo, log_fhi = math.log10(f_lo), math.log10(f_hi)
    db_top, db_bot = 120, -20

    def fxp(f):
        lf = math.log10(max(f, 1e-12))
        return gx0 + int((lf - log_flo) / (log_fhi - log_flo) * gw)

    def dby(db):
        db = max(min(db, db_top), db_bot)
        return gy0 + int((db_top - db) / (db_top - db_bot) * gh)

    # X 軸網格
    for d in range(0, 10):
        f = 10.0 ** d
        if f < f_lo or f > f_hi: continue
        gx = fxp(f)
        cv2.line(img, (gx, gy0), (gx, gy0+gh), LGRY, 1)
        if   f < 1e3: lbl = f"{int(f)}"
        elif f < 1e6: lbl = f"{int(f/1e3)}k"
        elif f < 1e9: lbl = f"{int(f/1e6)}M"
        else:         lbl = "1G"
        TC(img, lbl, gx, gy0+gh+20, GRY, 0.4, 1)
    T(img, "Hz", gx0+gw+16, gy0+gh+20, GRY, 0.42, 1)

    # Y 軸網格
    for db in range(db_bot, db_top+1, 20):
        gy = dby(db)
        cv2.line(img, (gx0, gy), (gx0+gw, gy), LGRY, 1)
        T(img, f"{db}", gx0-42, gy+4, GRY, 0.4, 1)
    T(img, "dB", gx0-42, gy0-10, GRY, 0.45, 1)

    # 0 dB 線
    cv2.line(img, (gx0, dby(0)), (gx0+gw, dby(0)), GRY, 1, cv2.LINE_AA)

    # ---- 開環增益 (單極點模型) ----
    A0_db  = 120.0
    A0_lin = 10 ** (A0_db / 20.0)
    fp     = GBW / A0_lin

    oloop = []
    for i in range(gw+1):
        lf = log_flo + (i/gw)*(log_fhi-log_flo)
        f  = 10 ** lf
        A  = A0_lin / math.sqrt(1 + (f/fp)**2)
        oloop.append((gx0+i, dby(20*math.log10(A))))
    cv2.polylines(img, [np.array(oloop, np.int32)], False, GRY, 2, cv2.LINE_AA)
    T(img, "Open-loop", gx0+12, gy0+18, GRY, 0.42, 1)

    # ---- 閉環增益 ----
    cloop = []
    for i in range(gw+1):
        lf = log_flo + (i/gw)*(log_fhi-log_flo)
        f  = 10 ** lf
        A  = gain / math.sqrt(1 + (f/f3db)**2)
        cloop.append((gx0+i, dby(20*math.log10(A))))
    cv2.polylines(img, [np.array(cloop, np.int32)], False, RED, 2, cv2.LINE_AA)

    # 平坦增益段
    if f_lo <= f3db <= f_hi:
        cv2.line(img, (gx0, dby(gain_db)), (fxp(f3db), dby(gain_db)), BLU, 1, cv2.LINE_AA)

    # -3dB 標記
    if f_lo <= f3db <= f_hi:
        gx3 = fxp(f3db)
        gy3 = dby(gain_db - 3)
        cv2.line(img, (gx3, gy0), (gx3, gy0+gh), PUR, 1, cv2.LINE_AA)
        cv2.circle(img, (gx3, gy3), 6, PUR, -1, cv2.LINE_AA)
        cv2.circle(img, (gx3, gy3), 6, (255,255,255), 1, cv2.LINE_AA)
        T(img, f"f-3dB = {fmt_freq(f3db)}", gx3+10, gy3-10, PUR, 0.45, 1)

    T(img, f"Closed-loop flat gain = {gain_db:.2f} dB", gx0+12, dby(gain_db)-10, RED, 0.45, 1)

    # ==================== 底部提示 ====================
    T(img, "q / ESC: quit      s: save", 30, H-14, GRY, 0.45, 1)

    cv2.imshow(WIN, img)
    k = cv2.waitKey(30) & 0xFF
    if k in (27, ord('q')):
        break
    elif k == ord('s'):
        cv2.imwrite("opamp_noninverting.png", img)
        print("已存檔 opamp_noninverting.png")

cv2.destroyAllWindows()