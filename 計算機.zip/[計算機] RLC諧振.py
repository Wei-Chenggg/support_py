import cv2, numpy as np, math

BG=(250,250,250); BLK=(35,35,35); GRY=(140,140,140); LGRY=(220,220,220)
RED=(60,60,220); BLU=(210,100,30); GRN=(60,150,60); ORG=(0,140,255); PUR=(180,80,180)
F = cv2.FONT_HERSHEY_SIMPLEX

def nothing(x): pass
def T(img,s,x,y,c=BLK,sc=0.5,t=1): cv2.putText(img,s,(x,y),F,sc,c,t,cv2.LINE_AA)
def TC(img,s,cx,y,c=BLK,sc=0.5,t=1):
    (w,_),_=cv2.getTextSize(s,F,sc,t); cv2.putText(img,s,(cx-w//2,y),F,sc,c,t,cv2.LINE_AA)

# ---------- 格式化 ----------
def fmt_freq(f):
    if f<=0: return "0"
    if f<1e3: return f"{f:.3f} Hz"
    if f<1e6: return f"{f/1e3:.3f} kHz"
    if f<1e9: return f"{f/1e6:.3f} MHz"
    return f"{f/1e9:.3f} GHz"

def fmt_ohm(z):
    if z<=0: return "0"
    if z<1:    return f"{z*1e3:.3f} mOhm"
    if z<1e3:  return f"{z:.3f} Ohm"
    if z<1e6:  return f"{z/1e3:.3f} kOhm"
    return f"{z/1e6:.3f} MOhm"

def fmt_ohm_ax(z):
    if z<1:    return f"{z*1e3:.0f}m"
    if z<1e3:  return f"{z:.0f}"
    if z<1e6:  return f"{z/1e3:.0f}k"
    return f"{z/1e6:.0f}M"

def fmt_H(h):
    if h<=0: return "0"
    if h<1e-6: return f"{h*1e9:.3f} nH"
    if h<1e-3: return f"{h*1e6:.3f} uH"
    if h<1:    return f"{h*1e3:.3f} mH"
    return f"{h:.3f} H"

def fmt_F(c):
    if c<=0: return "0"
    if c<1e-9: return f"{c*1e12:.3f} pF"
    if c<1e-6: return f"{c*1e9:.3f} nF"
    if c<1e-3: return f"{c*1e6:.3f} uF"
    return f"{c*1e3:.3f} mF"

# ---------- 數量級前綴 ----------
PREFIX = {
    'R': [("m", 1e-3), ("", 1.0), ("k", 1e3), ("M", 1e6)],
    'L': [("n", 1e-9), ("u", 1e-6), ("m", 1e-3), ("", 1.0)],
    'C': [("p", 1e-12), ("n", 1e-9), ("u", 1e-6), ("m", 1e-3)],
}
LVL_TXT = {
    'R': ["m","1","k","M"],
    'L': ["n","u","m","H"],
    'C': ["p","n","u","m"],
}

def draw_chip(img, x, y, active, color, labels):
    w, h, gap = 36, 28, 6
    for i, lv in enumerate(labels):
        cx = x + i*(w+gap)
        fill = color if i==active else (246,246,246)
        bd   = color if i==active else LGRY
        cv2.rectangle(img, (cx,y), (cx+w,y+h), fill, -1)
        cv2.rectangle(img, (cx,y), (cx+w,y+h), bd, 1)
        TC(img, lv, cx+w//2, y+h-9, (255,255,255) if i==active else GRY, 0.55, 1)

# ---------- 視窗與滑桿 ----------
WIN = "RLC Resonance"
cv2.namedWindow(WIN, cv2.WINDOW_AUTOSIZE)
cv2.createTrackbar("R level (m/1/k/M)", WIN, 1, 3, nothing)
cv2.createTrackbar("R value (1-999)",    WIN, 10, 999, nothing)
cv2.createTrackbar("L level (n/u/m/H)", WIN, 2, 3, nothing)
cv2.createTrackbar("L value (1-999)",    WIN, 1, 999, nothing)
cv2.createTrackbar("C level (p/n/u/m)", WIN, 1, 3, nothing)
cv2.createTrackbar("C value (1-999)",    WIN, 100, 999, nothing)
cv2.createTrackbar("Vin (V)",            WIN, 10, 24, nothing)

W, H = 1200, 660
print("操作說明:")
print("  R/L/C 各兩條滑桿: level (數量級) + value (有效數字)")
print("  1/2/3 鍵: 快速切換 R 的數量級 (m/1/k)")
print("  s      = 存檔 rlc_resonance.png")
print("  q/ESC  = 離開")

# ---------- 主迴圈 ----------
while True:
    R_lvl = cv2.getTrackbarPos("R level (m/1/k/M)", WIN)
    R_val = max(cv2.getTrackbarPos("R value (1-999)", WIN), 1)
    L_lvl = cv2.getTrackbarPos("L level (n/u/m/H)", WIN)
    L_val = max(cv2.getTrackbarPos("L value (1-999)", WIN), 1)
    C_lvl = cv2.getTrackbarPos("C level (p/n/u/m)", WIN)
    C_val = max(cv2.getTrackbarPos("C value (1-999)", WIN), 1)
    Vin   = max(cv2.getTrackbarPos("Vin (V)", WIN), 1)

    R = R_val * PREFIX['R'][R_lvl][1]
    L = L_val * PREFIX['L'][L_lvl][1]
    C = C_val * PREFIX['C'][C_lvl][1]

    # ---- 核心計算 ----
    omega0 = 1.0 / math.sqrt(L * C)
    f0     = omega0 / (2 * math.pi)
    Z0     = math.sqrt(L / C)          # 特性阻抗
    Q      = Z0 / R                     # 品質因數
    BW     = f0 / Q                     # 頻寬
    zeta   = R / (2 * Z0)               # 阻尼比
    Ires   = Vin / R                    # 諧振電流

    disc = math.sqrt(1 + 1 / (4 * Q * Q))
    f1   = f0 * (disc - 1 / (2 * Q))
    f2   = f0 * (disc + 1 / (2 * Q))

    img = np.full((H, W, 3), BG, np.uint8)

    # ---------- 標題 ----------
    T(img, "RLC Resonance  (Series)", 30, 44, BLK, 0.78, 2)
    T(img, "f0 = 1/(2*pi*sqrt(LC))     Q = Z0/R     BW = f0/Q", 480, 44, GRY, 0.5, 1)
    cv2.line(img, (30, 62), (W - 30, 62), LGRY, 1)

    # ---------- 級別晶片 ----------
    T(img, "R:", 30, 102, GRY, 0.55, 1)
    draw_chip(img, 60, 82, R_lvl, BLU, LVL_TXT['R'])
    T(img, "L:", 30, 157, GRY, 0.55, 1)
    draw_chip(img, 60, 137, L_lvl, GRN, LVL_TXT['L'])
    T(img, "C:", 30, 212, GRY, 0.55, 1)
    draw_chip(img, 60, 192, C_lvl, RED, LVL_TXT['C'])

    cv2.line(img, (30, 245), (450, 245), LGRY, 1)

    # ---------- 數據列 ----------
    rows = [
        ("R",     fmt_ohm(R),        BLU),
        ("L",     fmt_H(L),          GRN),
        ("C",     fmt_F(C),          RED),
        ("Vin",   f"{Vin} V",        BLK),
        ("f0",    fmt_freq(f0),      RED),
        ("Z0",    fmt_ohm(Z0),       ORG),
        ("Q",     f"{Q:.4f}",        PUR),
        ("BW",    fmt_freq(BW),      BLU),
        ("f1",    fmt_freq(f1),      GRY),
        ("f2",    fmt_freq(f2),      GRY),
        ("zeta",  f"{zeta:.5f}",     GRY),
        ("I@f0",  f"{Ires*1000:.3f} mA", ORG),
    ]
    y = 275
    for lab, val, col in rows:
        T(img, lab, 40,  y, GRY, 0.5, 1)
        T(img, val, 130, y, col, 0.5, 1)
        y += 27

    # ---------- 曲線面板 ----------
    px, py, pw, ph = 490, 110, 680, 450
    cv2.rectangle(img, (px, py), (px + pw, py + ph), (255,255,255), -1)
    cv2.rectangle(img, (px, py), (px + pw, py + ph), LGRY, 1)

    f_lo = f0 / 100
    f_hi = f0 * 100
    log_lo = math.log10(f_lo)
    log_hi = math.log10(f_hi)

    def fx(f):
        return px + int((math.log10(f) - log_lo) / (log_hi - log_lo) * pw)

    def z_mag(f):
        w = 2 * math.pi * f
        XL = w * L
        XC = 1.0 / (w * C)
        return math.sqrt(R*R + (XL - XC)**2)

    z_min = R / 5
    z_max = max(z_mag(f_lo), z_mag(f_hi)) * 1.5
    log_zlo = math.log10(z_min)
    log_zhi = math.log10(z_max)

    def fz(z):
        if z <= 0: z = z_min
        lg = math.log10(z)
        lg = max(log_zlo, min(log_zhi, lg))
        return py + ph - int((lg - log_zlo) / (log_zhi - log_zlo) * ph)

    # X 軸網格（每個 decade）
    for k in range(-2, 3):
        f = f0 * (10 ** k)
        if f_lo <= f <= f_hi:
            gx = fx(f)
            cv2.line(img, (gx, py), (gx, py + ph), LGRY, 1)
            TC(img, fmt_freq(f), gx, py + ph + 20, GRY, 0.38, 1)

    # Y 軸網格
    for k in range(int(math.floor(log_zlo)), int(math.ceil(log_zhi)) + 1):
        z = 10.0 ** k
        if z < z_min or z > z_max: continue
        gy = fz(z)
        cv2.line(img, (px, gy), (px + pw, gy), LGRY, 1)
        T(img, fmt_ohm_ax(z), px - 46, gy + 4, GRY, 0.4, 1)

    # |Z| 曲線
    N = 2400
    pts = []
    for i in range(N + 1):
        lf = log_lo + (i / N) * (log_hi - log_lo)
        f  = 10 ** lf
        pts.append((px + int(i / N * pw), fz(z_mag(f))))
    cv2.polylines(img, [np.array(pts, np.int32)], False, RED, 2, cv2.LINE_AA)

    # f1 / f2 半功率點（|Z| = √2 · R）
    z_half = R * math.sqrt(2)
    for f_mark, tag in ((f1, "f1"), (f2, "f2")):
        if f_lo <= f_mark <= f_hi:
            gx = fx(f_mark)
            gy = fz(z_half)
            cv2.line(img, (gx, py), (gx, py + ph), BLU, 1, cv2.LINE_AA)
            cv2.circle(img, (gx, gy), 5, BLU, -1, cv2.LINE_AA)
            cv2.circle(img, (gx, gy), 5, (255,255,255), 1, cv2.LINE_AA)
            T(img, tag, gx - 8, py + ph - 8, BLU, 0.42, 1)

    # f0 諧振點（|Z| = R）
    gx0 = fx(f0)
    gy0 = fz(R)
    cv2.line(img, (gx0, py), (gx0, py + ph), GRN, 1, cv2.LINE_AA)
    cv2.circle(img, (gx0, gy0), 7, GRN, -1, cv2.LINE_AA)
    cv2.circle(img, (gx0, gy0), 7, (255,255,255), 1, cv2.LINE_AA)
    T(img, "f0", gx0 + 6, py + 16, GRN, 0.48, 1)
    T(img, "|Z| = R", gx0 + 6, py + 36, GRN, 0.42, 1)

    # 座標軸標籤
    T(img, "frequency",  px + pw // 2 - 30, py + ph + 42, GRY, 0.48, 1)
    T(img, "|Z|",        px - 40, py - 8, GRY, 0.48, 1)

    # ---------- 底部提示 ----------
    T(img, "q / ESC: quit      s: save", 30, H - 16, GRY, 0.45, 1)

    cv2.imshow(WIN, img)
    k = cv2.waitKey(30) & 0xFF
    if k in (27, ord('q')):
        break
    elif k == ord('s'):
        cv2.imwrite("rlc_resonance.png", img)
        print("已存檔 rlc_resonance.png")

cv2.destroyAllWindows()